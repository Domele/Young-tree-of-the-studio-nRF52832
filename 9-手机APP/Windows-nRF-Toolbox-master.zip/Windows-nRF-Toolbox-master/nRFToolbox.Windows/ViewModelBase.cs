﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nRFToolbox.Base
{
	public partial class ViewModelBase
	{
		//part of ViewModelBase
	}
}
