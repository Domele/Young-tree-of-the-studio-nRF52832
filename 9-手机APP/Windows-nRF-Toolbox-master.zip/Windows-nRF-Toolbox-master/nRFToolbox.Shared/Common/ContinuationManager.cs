﻿/*Copyright (c) 2015, Nordic Semiconductor ASA
 *
 *Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 *1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 *2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other 
 *materials provided with the distribution.
 *
 *3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific 
 *prior written permission.
 *
 *THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *PURPOSE ARE DISCLAIMED. *IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF *SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, *DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED *OF THE POSSIBILITY OF SUCH DAMAGE.
 */
using System;
using System.Collections.Generic;
using System.Text;
using Windows.ApplicationModel.Activation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace nRFToolbox.Common
{
#if WINDOWS_PHONE_APP
	public class ContinuationManager
	{
		IContinuationActivatedEventArgs args = null;
		bool handled = false;
		Guid id = Guid.Empty;

		/// <summary>
		/// Sets the ContinuationArgs for this instance. Using default Frame of current Window
		/// Should be called by the main activation handling code in App.xaml.cs
		/// </summary>
		/// <param name="args">The activation args</param>
		internal void Continue(IContinuationActivatedEventArgs args)
		{
			Continue(args, Window.Current.Content as Frame);
		}

		/// <summary>
		/// Sets the ContinuationArgs for this instance. Should be called by the main activation
		/// handling code in App.xaml.cs
		/// </summary>
		/// <param name="args">The activation args</param>
		/// <param name="rootFrame">The frame control that contains the current page</param>
		internal void Continue(IContinuationActivatedEventArgs args, Frame rootFrame)
		{
			if (args == null)
				throw new ArgumentNullException("args");

			if (this.args != null && !handled)
				throw new InvalidOperationException("Can't set args more than once");

			this.args = args;
			this.handled = false;
			this.id = Guid.NewGuid();

			if (rootFrame == null)
				return;

			switch (args.Kind)
			{
				case ActivationKind.PickFileContinuation:
					var fileOpenPickerPage = rootFrame.Content as IFileOpenPickerContinuable;
					if (fileOpenPickerPage != null)
					{
						fileOpenPickerPage.ContinueFileOpenPicker(args as FileOpenPickerContinuationEventArgs);
					}
					break;

				case ActivationKind.PickSaveFileContinuation:
					var fileSavePickerPage = rootFrame.Content as IFileSavePickerContinuable;
					if (fileSavePickerPage != null)
					{
						fileSavePickerPage.ContinueFileSavePicker(args as FileSavePickerContinuationEventArgs);
					}
					break;

				case ActivationKind.PickFolderContinuation:
					var folderPickerPage = rootFrame.Content as IFolderPickerContinuable;
					if (folderPickerPage != null)
					{
						folderPickerPage.ContinueFolderPicker(args as FolderPickerContinuationEventArgs);
					}
					break;

				case ActivationKind.WebAuthenticationBrokerContinuation:
					var wabPage = rootFrame.Content as IWebAuthenticationContinuable;
					if (wabPage != null)
					{
						wabPage.ContinueWebAuthentication(args as WebAuthenticationBrokerContinuationEventArgs);
					}
					break;
			}
		}

		/// <summary>
		/// Marks the contination data as 'stale', meaning that it is probably no longer of
		/// any use. Called when the app is suspended (to ensure future activations don't appear
		/// to be for the same continuation) and whenever the continuation data is retrieved 
		/// (so that it isn't retrieved on subsequent navigations)
		/// </summary>
		internal void MarkAsStale()
		{
			this.handled = true;
		}

		/// <summary>
		/// Retrieves the continuation args, if they have not already been retrieved, and 
		/// prevents further retrieval via this property (to avoid accidentla double-usage)
		/// </summary>
		public IContinuationActivatedEventArgs ContinuationArgs
		{
			get
			{
				if (handled)
					return null;
				MarkAsStale();
				return args;
			}
		}

		/// <summary>
		/// Unique identifier for this particular continuation. Most useful for components that 
		/// retrieve the continuation data via <see cref="GetContinuationArgs"/> and need
		/// to perform their own replay check
		/// </summary>
		public Guid Id { get { return id; } }

		/// <summary>
		/// Retrieves the continuation args, optionally retrieving them even if they have already
		/// been retrieved
		/// </summary>
		/// <param name="includeStaleArgs">Set to true to return args even if they have previously been returned</param>
		/// <returns>The continuation args, or null if there aren't any</returns>
		public IContinuationActivatedEventArgs GetContinuationArgs(bool includeStaleArgs)
		{
			if (!includeStaleArgs && handled)
				return null;
			MarkAsStale();
			return args;
		}
	}

	/// <summary>
	/// Implement this interface if your page invokes the file open picker
	/// API.
	/// </summary>
	interface IFileOpenPickerContinuable
	{
		/// <summary>
		/// This method is invoked when the file open picker returns picked
		/// files
		/// </summary>
		/// <param name="args">Activated event args object that contains returned files from file open picker</param>
		void ContinueFileOpenPicker(FileOpenPickerContinuationEventArgs args);
	}

	/// <summary>
	/// Implement this interface if your page invokes the file save picker
	/// API
	/// </summary>
	interface IFileSavePickerContinuable
	{
		/// <summary>
		/// This method is invoked when the file save picker returns saved
		/// files
		/// </summary>
		/// <param name="args">Activated event args object that contains returned file from file save picker</param>
		void ContinueFileSavePicker(FileSavePickerContinuationEventArgs args);
	}

	/// <summary>
	/// Implement this interface if your page invokes the favoriteFolder picker API
	/// </summary>
	interface IFolderPickerContinuable
	{
		/// <summary>
		/// This method is invoked when the favoriteFolder picker returns the picked
		/// favoriteFolder
		/// </summary>
		/// <param name="args">Activated event args object that contains returned favoriteFolder from favoriteFolder picker</param>
		void ContinueFolderPicker(FolderPickerContinuationEventArgs args);
	}

	/// <summary>
	/// Implement this interface if your page invokes the web authentication
	/// broker
	/// </summary>
	interface IWebAuthenticationContinuable
	{
		/// <summary>
		/// This method is invoked when the web authentication broker returns
		/// with the authentication result
		/// </summary>
		/// <param name="args">Activated event args object that contains returned authentication token</param>
		void ContinueWebAuthentication(WebAuthenticationBrokerContinuationEventArgs args);
	}
#endif
}
